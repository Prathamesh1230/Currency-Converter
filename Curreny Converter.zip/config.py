# Get your own key from https://www.exchangerate-api.com/
API_KEY = "Your_API_Key"
API_URL = f"API key URL"

import tkinter as tk
from gui import CurrencyConverterApp

if __name__ == "__main__":
    root = tk.Tk()
    app = CurrencyConverterApp(root)
    root.mainloop()

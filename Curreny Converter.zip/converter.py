def convert_currency(amount, rate):
    return round(amount * rate, 2)
